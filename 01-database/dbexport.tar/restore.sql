--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.2
-- Dumped by pg_dump version 9.6.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = tk_basdat_a02, pg_catalog;

ALTER TABLE ONLY tk_basdat_a02.ruang_ujian DROP CONSTRAINT ruang_ujian_kota_fkey;
ALTER TABLE ONLY tk_basdat_a02.rekomendasi DROP CONSTRAINT rekomendasi_id_pendaftaran_fkey;
ALTER TABLE ONLY tk_basdat_a02.program_studi DROP CONSTRAINT program_studi_jenjang_fkey;
ALTER TABLE ONLY tk_basdat_a02.pengawas DROP CONSTRAINT pengawas_lokasi_kota_fkey;
ALTER TABLE ONLY tk_basdat_a02.penerimaan_prodi DROP CONSTRAINT penerimaan_prodi_nomor_periode_fkey;
ALTER TABLE ONLY tk_basdat_a02.penerimaan_prodi DROP CONSTRAINT penerimaan_prodi_kode_prodi_fkey;
ALTER TABLE ONLY tk_basdat_a02.pendaftaran_uui DROP CONSTRAINT pendaftaran_uui_id_pendaftaran_fkey;
ALTER TABLE ONLY tk_basdat_a02.pendaftaran_semas_sarjana DROP CONSTRAINT pendaftaran_semas_sarjana_id_pendaftaran_fkey;
ALTER TABLE ONLY tk_basdat_a02.pendaftaran_semas_pascasarjana DROP CONSTRAINT pendaftaran_semas_pascasarjana_jenjang_terakhir_fkey;
ALTER TABLE ONLY tk_basdat_a02.pendaftaran_semas_pascasarjana DROP CONSTRAINT pendaftaran_semas_pascasarjana_jenjang_fkey;
ALTER TABLE ONLY tk_basdat_a02.pendaftaran_semas_pascasarjana DROP CONSTRAINT pendaftaran_semas_pascasarjana_id_pendaftaran_fkey;
ALTER TABLE ONLY tk_basdat_a02.pendaftaran_semas DROP CONSTRAINT pendaftaran_semas_lokasi_kota_fkey;
ALTER TABLE ONLY tk_basdat_a02.pendaftaran_semas DROP CONSTRAINT pendaftaran_semas_id_pendaftaran_fkey;
ALTER TABLE ONLY tk_basdat_a02.pendaftaran_prodi DROP CONSTRAINT pendaftaran_prodi_kode_prodi_fkey;
ALTER TABLE ONLY tk_basdat_a02.pendaftaran_prodi DROP CONSTRAINT pendaftaran_prodi_id_pendaftaran_fkey;
ALTER TABLE ONLY tk_basdat_a02.pendaftaran DROP CONSTRAINT pendaftaran_pelamar_fkey;
ALTER TABLE ONLY tk_basdat_a02.pendaftaran DROP CONSTRAINT pendaftaran_nomor_periode_fkey;
ALTER TABLE ONLY tk_basdat_a02.pembayaran DROP CONSTRAINT pembayaran_id_pendaftaran_fkey;
ALTER TABLE ONLY tk_basdat_a02.pelamar DROP CONSTRAINT pelamar_username_fkey;
ALTER TABLE ONLY tk_basdat_a02.lokasi_jadwal DROP CONSTRAINT lokasi_jadwal_nomor_periode_fkey;
ALTER TABLE ONLY tk_basdat_a02.lokasi_jadwal DROP CONSTRAINT lokasi_jadwal_kota_fkey;
ALTER TABLE ONLY tk_basdat_a02.jadwal_penting DROP CONSTRAINT jadwal_penting_nomor_fkey;
ALTER TABLE ONLY tk_basdat_a02.jadwal_penting DROP CONSTRAINT jadwal_penting_jenjang_fkey;
SET search_path = sirenkom, pg_catalog;

ALTER TABLE ONLY sirenkom.peminjaman DROP CONSTRAINT peminjaman_no_anggota_fkey;
ALTER TABLE ONLY sirenkom.peminjaman DROP CONSTRAINT peminjaman_id_petugas_fkey;
ALTER TABLE ONLY sirenkom.detail_peminjaman DROP CONSTRAINT detail_peminjaman_no_komik_fkey;
ALTER TABLE ONLY sirenkom.detail_peminjaman DROP CONSTRAINT detail_peminjaman_id_peminjaman_fkey;
SET search_path = latihan_kuis_1, pg_catalog;

ALTER TABLE ONLY latihan_kuis_1.transkrip DROP CONSTRAINT transkrip_npm_fkey;
ALTER TABLE ONLY latihan_kuis_1.transkrip DROP CONSTRAINT transkrip_kode_mk_fkey1;
ALTER TABLE ONLY latihan_kuis_1.transkrip DROP CONSTRAINT transkrip_kode_mk_fkey;
ALTER TABLE ONLY latihan_kuis_1.mahasiswa DROP CONSTRAINT mahasiswa_nip_pa_fkey;
ALTER TABLE ONLY latihan_kuis_1.kelas DROP CONSTRAINT kelas_nip_dosen_fkey;
ALTER TABLE ONLY latihan_kuis_1.kelas DROP CONSTRAINT kelas_kode_mk_fkey;
SET search_path = aviationtest, pg_catalog;

ALTER TABLE ONLY aviationtest.seat_reservation DROP CONSTRAINT seat_reservation_flight_num_fkey1;
ALTER TABLE ONLY aviationtest.seat_reservation DROP CONSTRAINT seat_reservation_flight_num_fkey;
ALTER TABLE ONLY aviationtest.flight_instance DROP CONSTRAINT flight_instance_flight_num_fkey;
ALTER TABLE ONLY aviationtest.flight_instance DROP CONSTRAINT flight_instance_airplane_id_fkey;
ALTER TABLE ONLY aviationtest.flight DROP CONSTRAINT flight_dept_airport_fkey;
ALTER TABLE ONLY aviationtest.flight DROP CONSTRAINT flight_arr_airport_fkey;
ALTER TABLE ONLY aviationtest.fare DROP CONSTRAINT fare_flight_num_fkey;
ALTER TABLE ONLY aviationtest.airplane DROP CONSTRAINT airplane_airplane_type_fkey;
SET search_path = tk_basdat_a02, pg_catalog;

DROP TRIGGER trigger_jumlah_pelamar ON tk_basdat_a02.pendaftaran_prodi;
DROP TRIGGER trigger_jumlah_diterima ON tk_basdat_a02.pendaftaran_prodi;
SET search_path = sirenkom, pg_catalog;

DROP TRIGGER volume_trigger ON sirenkom.detail_peminjaman;
DROP TRIGGER jumlah_peminjaman_trigger ON sirenkom.detail_peminjaman;
DROP TRIGGER frekuensi_dipinjam_trigger ON sirenkom.detail_peminjaman;
SET search_path = tk_basdat_a02, pg_catalog;

ALTER TABLE ONLY tk_basdat_a02.ruang_ujian DROP CONSTRAINT ruang_ujian_pkey;
ALTER TABLE ONLY tk_basdat_a02.rekomendasi DROP CONSTRAINT rekomendasi_pkey;
ALTER TABLE ONLY tk_basdat_a02.program_studi DROP CONSTRAINT program_studi_pkey;
ALTER TABLE ONLY tk_basdat_a02.periode_penerimaan DROP CONSTRAINT periode_penerimaan_pkey;
ALTER TABLE ONLY tk_basdat_a02.pengawas DROP CONSTRAINT pengawas_pkey;
ALTER TABLE ONLY tk_basdat_a02.penerimaan_prodi DROP CONSTRAINT penerimaan_prodi_pkey;
ALTER TABLE ONLY tk_basdat_a02.pendaftaran_uui DROP CONSTRAINT pendaftaran_uui_pkey;
ALTER TABLE ONLY tk_basdat_a02.pendaftaran_semas_sarjana DROP CONSTRAINT pendaftaran_semas_sarjana_pkey;
ALTER TABLE ONLY tk_basdat_a02.pendaftaran_semas DROP CONSTRAINT pendaftaran_semas_pkey;
ALTER TABLE ONLY tk_basdat_a02.pendaftaran_semas_pascasarjana DROP CONSTRAINT pendaftaran_semas_pascasarjana_pkey;
ALTER TABLE ONLY tk_basdat_a02.pendaftaran_prodi DROP CONSTRAINT pendaftaran_prodi_pkey;
ALTER TABLE ONLY tk_basdat_a02.pendaftaran DROP CONSTRAINT pendaftaran_pkey;
ALTER TABLE ONLY tk_basdat_a02.pembayaran DROP CONSTRAINT pembayaran_pkey;
ALTER TABLE ONLY tk_basdat_a02.pelamar DROP CONSTRAINT pelamar_pkey;
ALTER TABLE ONLY tk_basdat_a02.pelamar DROP CONSTRAINT pelamar_email_key;
ALTER TABLE ONLY tk_basdat_a02.lokasi_ujian DROP CONSTRAINT lokasi_ujian_pkey;
ALTER TABLE ONLY tk_basdat_a02.lokasi_jadwal DROP CONSTRAINT lokasi_jadwal_pkey;
ALTER TABLE ONLY tk_basdat_a02.jenjang DROP CONSTRAINT jenjang_pkey;
ALTER TABLE ONLY tk_basdat_a02.jadwal_penting DROP CONSTRAINT jadwal_penting_pkey;
ALTER TABLE ONLY tk_basdat_a02.akun DROP CONSTRAINT akun_pkey;
SET search_path = sirenkom, pg_catalog;

ALTER TABLE ONLY sirenkom.petugas DROP CONSTRAINT petugas_pkey;
ALTER TABLE ONLY sirenkom.peminjaman DROP CONSTRAINT peminjaman_pkey;
ALTER TABLE ONLY sirenkom.komik DROP CONSTRAINT komik_pkey;
ALTER TABLE ONLY sirenkom.detail_peminjaman DROP CONSTRAINT detail_peminjaman_pkey;
ALTER TABLE ONLY sirenkom.anggota DROP CONSTRAINT anggota_pkey;
ALTER TABLE ONLY sirenkom.anggota DROP CONSTRAINT anggota_no_identitas_key;
SET search_path = latihan_kuis_1, pg_catalog;

ALTER TABLE ONLY latihan_kuis_1.transkrip DROP CONSTRAINT transkrip_pkey;
ALTER TABLE ONLY latihan_kuis_1.mata_kuliah DROP CONSTRAINT mata_kuliah_pkey;
ALTER TABLE ONLY latihan_kuis_1.mahasiswa DROP CONSTRAINT mahasiswa_pkey;
ALTER TABLE ONLY latihan_kuis_1.kelas DROP CONSTRAINT kelas_pkey;
ALTER TABLE ONLY latihan_kuis_1.dosen DROP CONSTRAINT dosen_pkey;
SET search_path = aviationtest, pg_catalog;

ALTER TABLE ONLY aviationtest.seat_reservation DROP CONSTRAINT seat_reservation_pkey;
ALTER TABLE ONLY aviationtest.flight DROP CONSTRAINT flight_pkey;
ALTER TABLE ONLY aviationtest.flight_instance DROP CONSTRAINT flight_instance_pkey;
ALTER TABLE ONLY aviationtest.fare DROP CONSTRAINT fare_pkey;
ALTER TABLE ONLY aviationtest.airport DROP CONSTRAINT airport_pkey;
ALTER TABLE ONLY aviationtest.airplane_type DROP CONSTRAINT airplane_type_pkey;
ALTER TABLE ONLY aviationtest.airplane DROP CONSTRAINT airplane_pkey;
SET search_path = tk_basdat_a02, pg_catalog;

SET search_path = sirenkom, pg_catalog;

SET search_path = latihan_kuis_1, pg_catalog;

SET search_path = aviationtest, pg_catalog;

SET search_path = tk_basdat_a02, pg_catalog;

ALTER TABLE tk_basdat_a02.program_studi ALTER COLUMN kode DROP DEFAULT;
ALTER TABLE tk_basdat_a02.pendaftaran ALTER COLUMN id DROP DEFAULT;
ALTER TABLE tk_basdat_a02.pembayaran ALTER COLUMN id DROP DEFAULT;
SET search_path = sirenkom, pg_catalog;

ALTER TABLE sirenkom.peminjaman ALTER COLUMN id_peminjaman DROP DEFAULT;
SET search_path = tk_basdat_a02, pg_catalog;

DROP TABLE tk_basdat_a02.ruang_ujian;
DROP TABLE tk_basdat_a02.rekomendasi;
DROP SEQUENCE tk_basdat_a02.program_studi_kode_seq;
DROP TABLE tk_basdat_a02.program_studi;
DROP TABLE tk_basdat_a02.periode_penerimaan;
DROP TABLE tk_basdat_a02.pengawas;
DROP TABLE tk_basdat_a02.penerimaan_prodi;
DROP TABLE tk_basdat_a02.pendaftaran_uui;
DROP TABLE tk_basdat_a02.pendaftaran_semas_sarjana;
DROP TABLE tk_basdat_a02.pendaftaran_semas_pascasarjana;
DROP TABLE tk_basdat_a02.pendaftaran_semas;
DROP TABLE tk_basdat_a02.pendaftaran_prodi;
DROP SEQUENCE tk_basdat_a02.pendaftaran_id_seq;
DROP TABLE tk_basdat_a02.pendaftaran;
DROP SEQUENCE tk_basdat_a02.pembayaran_id_seq;
DROP TABLE tk_basdat_a02.pembayaran;
DROP TABLE tk_basdat_a02.pelamar;
DROP TABLE tk_basdat_a02.lokasi_ujian;
DROP TABLE tk_basdat_a02.lokasi_jadwal;
DROP TABLE tk_basdat_a02.jenjang;
DROP TABLE tk_basdat_a02.jadwal_penting;
DROP TABLE tk_basdat_a02.akun;
SET search_path = sirenkom, pg_catalog;

DROP TABLE sirenkom.petugas;
DROP SEQUENCE sirenkom.peminjaman_id_peminjaman_seq;
DROP TABLE sirenkom.peminjaman;
DROP TABLE sirenkom.komik;
DROP TABLE sirenkom.detail_peminjaman;
DROP TABLE sirenkom.anggota;
SET search_path = latihan_kuis_1, pg_catalog;

DROP TABLE latihan_kuis_1.transkrip;
DROP TABLE latihan_kuis_1.mata_kuliah;
DROP TABLE latihan_kuis_1.mahasiswa;
DROP TABLE latihan_kuis_1.kelas;
DROP TABLE latihan_kuis_1.dosen;
SET search_path = aviationtest, pg_catalog;

DROP TABLE aviationtest.seat_reservation;
DROP TABLE aviationtest.flight_instance;
DROP TABLE aviationtest.flight;
DROP TABLE aviationtest.fare;
DROP TABLE aviationtest.airport;
DROP TABLE aviationtest.airplane_type;
DROP TABLE aviationtest.airplane;
SET search_path = tk_basdat_a02, pg_catalog;

DROP FUNCTION tk_basdat_a02.update_jumlah_pelamar();
DROP FUNCTION tk_basdat_a02.update_jumlah_diterima();
DROP FUNCTION tk_basdat_a02.prefill_jumlah_pelamar();
DROP FUNCTION tk_basdat_a02.prefill_jumlah_diterima();
SET search_path = sirenkom, pg_catalog;

DROP FUNCTION sirenkom.volume_constraint();
DROP FUNCTION sirenkom.perbarui_kolom_frekuensi_dipinjam_tabel_komik();
DROP FUNCTION sirenkom.jumlah_peminjaman_constraint();
DROP FUNCTION sirenkom.hitung_semua_frekuensi();
DROP FUNCTION sirenkom.beri_status();
SET search_path = aviationtest, pg_catalog;

DROP DOMAIN aviationtest.noflight;
DROP DOMAIN aviationtest.airportcode;
DROP EXTENSION plpgsql;
DROP SCHEMA tk_basdat_a02;
DROP SCHEMA sirenkom;
DROP SCHEMA public;
DROP SCHEMA latihan_kuis_1;
DROP SCHEMA aviationtest;
--
-- Name: aviationtest; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA aviationtest;


--
-- Name: latihan_kuis_1; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA latihan_kuis_1;


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: sirenkom; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA sirenkom;


--
-- Name: tk_basdat_a02; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA tk_basdat_a02;


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = aviationtest, pg_catalog;

--
-- Name: airportcode; Type: DOMAIN; Schema: aviationtest; Owner: -
--

CREATE DOMAIN airportcode AS character(3);


--
-- Name: noflight; Type: DOMAIN; Schema: aviationtest; Owner: -
--

CREATE DOMAIN noflight AS character varying(6);


SET search_path = sirenkom, pg_catalog;

--
-- Name: beri_status(); Type: FUNCTION; Schema: sirenkom; Owner: -
--

CREATE FUNCTION beri_status() RETURNS void
    LANGUAGE plpgsql
    AS $$ 
	DECLARE row RECORD; 
	DECLARE row1 RECORD;
	BEGIN 
		FOR row IN 		
		SELECT no_anggota
		FROM ANGGOTA A
		WHERE EXISTS (
			SELECT * 
			FROM PEMINJAMAN PE, DETAIL_PEMINJAMAN D_P
			WHERE A.no_anggota = PE.no_anggota 
			AND PE.id_peminjaman = D_P.id_peminjaman
			AND D_P.tgl_kembali IS NULL
		)
		
		LOOP 
			UPDATE ANGGOTA SET status = false 
			WHERE no_anggota = row.no_anggota; 
		END LOOP; 
		
		
		FOR row1 IN
		SELECT no_anggota
		FROM ANGGOTA A
		WHERE NOT EXISTS (
			SELECT * 
			FROM PEMINJAMAN PE, DETAIL_PEMINJAMAN D_P
			WHERE A.no_anggota = PE.no_anggota 
			AND PE.id_peminjaman = D_P.id_peminjaman
			AND D_P.tgl_kembali IS NULL
		)
		
		LOOP 
			UPDATE ANGGOTA SET status = true 
			WHERE no_anggota = row1.no_anggota; 
		END LOOP; 
	END; 
$$;


--
-- Name: hitung_semua_frekuensi(); Type: FUNCTION; Schema: sirenkom; Owner: -
--

CREATE FUNCTION hitung_semua_frekuensi() RETURNS void
    LANGUAGE plpgsql
    AS $$ 
	DECLARE row RECORD; 
	BEGIN 
		FOR row IN 
		SELECT K.no_komik as no_kmk, COUNT(DP.*) AS frekuensi 
		FROM KOMIK K, DETAIL_PEMINJAMAN DP 
		WHERE K.no_komik = DP.no_komik 
		GROUP BY K.no_komik 
		
		LOOP 
			UPDATE KOMIK SET frekuensi_dipinjam = row.frekuensi 
			WHERE no_komik = row.no_kmk; 
		END LOOP; 
	END; 
$$;


--
-- Name: jumlah_peminjaman_constraint(); Type: FUNCTION; Schema: sirenkom; Owner: -
--

CREATE FUNCTION jumlah_peminjaman_constraint() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ 
	DECLARE jml_peminjaman INTEGER; 
	BEGIN 
		SELECT count(NEW.id_peminjaman) INTO jml_peminjaman 
		FROM DETAIL_PEMINJAMAN D_P
		WHERE D_P.id_peminjaman = NEW.id_peminjaman; 
		
		IF (TG_OP = 'INSERT') THEN 
			IF( jml_peminjaman > 3) THEN 
				RAISE EXCEPTION 'Tidak boleh meminjam lebih dari 3 komik'; 
			END IF; 
		RETURN NEW; 
		END IF; 
	END; 
$$;


--
-- Name: perbarui_kolom_frekuensi_dipinjam_tabel_komik(); Type: FUNCTION; Schema: sirenkom; Owner: -
--

CREATE FUNCTION perbarui_kolom_frekuensi_dipinjam_tabel_komik() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ 
	DECLARE curr_frekuensi_dipinjam1 INTEGER; 
	DECLARE curr_frekuensi_dipinjam2 INTEGER;
	BEGIN 
	
				
		IF (TG_OP = 'INSERT') THEN 
			
			SELECT frekuensi_dipinjam INTO curr_frekuensi_dipinjam1
			FROM KOMIK K
			WHERE NEW.no_komik = K.no_komik;
				
			UPDATE KOMIK SET frekuensi_dipinjam = curr_frekuensi_dipinjam1 + 1
			WHERE NEW.no_komik = no_komik;
			
		END IF;
		
		IF(TG_OP = 'UPDATE') THEN
			
			SELECT frekuensi_dipinjam INTO curr_frekuensi_dipinjam1
			FROM KOMIK K
			WHERE NEW.no_komik = K.no_komik;
			
			SELECT frekuensi_dipinjam INTO curr_frekuensi_dipinjam2
			FROM KOMIK K
			WHERE OLD.no_komik = K.no_komik;
			
			
			UPDATE KOMIK SET frekuensi_dipinjam = curr_frekuensi_dipinjam1 + 1
			WHERE  no_komik = NEW.no_komik;
			
			UPDATE KOMIK SET frekuensi_dipinjam = curr_frekuensi_dipinjam2 - 1
			WHERE  no_komik = OLD.no_komik;
		
		END IF;
		
		IF(TG_OP = 'DELETE') THEN
			
			SELECT frekuensi_dipinjam INTO curr_frekuensi_dipinjam1
			FROM KOMIK K
			WHERE OLD.no_komik = K.no_komik;
			
			UPDATE KOMIK SET frekuensi_dipinjam = curr_frekuensi_dipinjam1 - 1
			WHERE OLD.no_komik = no_komik;
		
		END IF;
		RETURN NEW;
	END; 
$$;


--
-- Name: volume_constraint(); Type: FUNCTION; Schema: sirenkom; Owner: -
--

CREATE FUNCTION volume_constraint() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ 
	DECLARE Jml_volume INTEGER; 
	BEGIN 
		SELECT jumlah_volume INTO jml_volume 
		FROM KOMIK K 
		WHERE K.no_komik = NEW.no_komik; 
		
		IF (TG_OP = 'INSERT') THEN 
			IF(NEW.no_volume > jml_volume) THEN RAISE EXCEPTION 'Error : Nomor volume komik tidak ada'; 
			END IF; 
			RETURN NEW; 
		END IF; 
	END; 
$$;


SET search_path = tk_basdat_a02, pg_catalog;

--
-- Name: prefill_jumlah_diterima(); Type: FUNCTION; Schema: tk_basdat_a02; Owner: -
--

CREATE FUNCTION prefill_jumlah_diterima() RETURNS void
    LANGUAGE plpgsql
    AS $$
  declare
    row record;
    jml_diterima integer;
  begin
    for row in
      select * from penerimaan_prodi
    loop
      select count(*) into jml_diterima
      from pendaftaran_prodi pp
      join pendaftaran p on p.id = pp.id_pendaftaran
      where
        pp.kode_prodi = row.kode_prodi and
        p.nomor_periode = row.nomor_periode and
        p.tahun_periode = row.tahun_periode and
        pp.status_lulus = true;

      update penerimaan_prodi
      set jumlah_diterima = jml_diterima
      where
        nomor_periode = row.nomor_periode and
        kode_prodi = row.kode_prodi and
        tahun_periode = row.tahun_periode;
    end loop;
  end;
$$;


--
-- Name: prefill_jumlah_pelamar(); Type: FUNCTION; Schema: tk_basdat_a02; Owner: -
--

CREATE FUNCTION prefill_jumlah_pelamar() RETURNS void
    LANGUAGE plpgsql
    AS $$
  declare
    row record;
    jml_pelamar integer;
  begin
    for row in
      select * from penerimaan_prodi
    loop
      select count(*) into jml_pelamar
      from pendaftaran_prodi pp
      join pendaftaran p on p.id = pp.id_pendaftaran
      where
        pp.kode_prodi = row.kode_prodi and
        p.nomor_periode = row.nomor_periode and
        p.tahun_periode = row.tahun_periode;

      update penerimaan_prodi
      set jumlah_pelamar = jml_pelamar
      where
        nomor_periode = row.nomor_periode and
        kode_prodi = row.kode_prodi and
        tahun_periode = row.tahun_periode;
    end loop;
  end;
$$;


--
-- Name: update_jumlah_diterima(); Type: FUNCTION; Schema: tk_basdat_a02; Owner: -
--

CREATE FUNCTION update_jumlah_diterima() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  declare
    pendaftaran_diterima boolean;
    nomor_periode_new integer;
    nomor_periode_old integer;
    tahun_periode_new char(4);
    tahun_periode_old char(4);
  begin
    if (tg_op = 'UPDATE') then

      select nomor_periode into nomor_periode_new
      from pendaftaran
      where id = new.id_pendaftaran;

      select nomor_periode into nomor_periode_old
      from pendaftaran
      where id = old.id_pendaftaran;

      select tahun_periode into tahun_periode_new
      from pendaftaran
      where id = new.id_pendaftaran;

      select tahun_periode into tahun_periode_old
      from pendaftaran
      where id = old.id_pendaftaran;

      if (new.status_lulus) then
        select count(p) > 0 into pendaftaran_diterima
        from pendaftaran_prodi p
        where p.id_pendaftaran = new.id_pendaftaran
          and kode_prodi <> new.kode_prodi
          and status_lulus = true;

        if (pendaftaran_diterima) then
          raise 'ERROR: Sudah lulus di prodi lain';
        end if;

        update penerimaan_prodi pp
        set jumlah_diterima = jumlah_diterima + 1
        where
          pp.kode_prodi = new.kode_prodi and
          pp.nomor_periode = nomor_periode_new and
          pp.tahun_periode = tahun_periode_new;
      end if;

      if (old.status_lulus) then
        update penerimaan_prodi pp
        set jumlah_diterima = jumlah_diterima - 1
        where
          pp.kode_prodi = old.kode_prodi and
          pp.nomor_periode = nomor_periode_old and
          pp.tahun_periode = tahun_periode_old;
      end if;

    end if;

    return new;
  end;
$$;


--
-- Name: update_jumlah_pelamar(); Type: FUNCTION; Schema: tk_basdat_a02; Owner: -
--

CREATE FUNCTION update_jumlah_pelamar() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  declare
    nomor_periode_new integer;
    nomor_periode_old integer;
    tahun_periode_new char(4);
    tahun_periode_old char(4);
    jumlah integer;
    jml_pelamar_1 integer;
    jml_pelamar_2 integer;
  begin
      IF (TG_OP = 'INSERT') THEN
        select nomor_periode into nomor_periode_new
        from pendaftaran
        where id = new.id_pendaftaran;

        select tahun_periode into tahun_periode_new
        from pendaftaran
        where id = new.id_pendaftaran;

        select jumlah_pelamar into jumlah from penerimaan_prodi pp, pendaftaran_prodi p
        where p.id_pendaftaran = new.id_pendaftaran and 
        pp.kode_prodi = NEW.kode_prodi and
        pp.nomor_periode = nomor_periode_new and
        pp.tahun_periode = tahun_periode_new;
        jumlah := jumlah + 1;
      ELSIF (TG_OP = 'DELETE') THEN 
        select nomor_periode into nomor_periode_old
        from pendaftaran
        where id = old.id_pendaftaran;

        select tahun_periode into tahun_periode_old
        from pendaftaran
        where id = old.id_pendaftaran;

        select jumlah_pelamar into jumlah from penerimaan_prodi pp, pendaftaran_prodi p
        where p.id_pendaftaran = new.id_pendaftaran and 
        pp.kode_prodi = NEW.kode_prodi and
        pp.nomor_periode = nomor_periode_new and
        pp.tahun_periode = tahun_periode_new;
        jumlah := jumlah - 1;
      ELSIF (TG_OP = 'UPDATE') THEN

        select nomor_periode into nomor_periode_old
        from pendaftaran
        where id = old.id_pendaftaran;

        select tahun_periode into tahun_periode_old
        from pendaftaran
        where id = old.id_pendaftaran;

        select nomor_periode into nomor_periode_new
        from pendaftaran
        where id = new.id_pendaftaran;

        select tahun_periode into tahun_periode_new
        from pendaftaran
        where id = new.id_pendaftaran;

        select jumlah_pelamar as jml_pelamar_1 from penerimaan_prodi pp, pendaftaran_prodi p
        where p.id_pendaftaran = new.id_pendaftaran and 
        pp.kode_prodi = NEW.kode_prodi and
        pp.nomor_periode = nomor_periode_new and
        pp.tahun_periode = tahun_periode_new;
        select jumlah_pelamar as jml_pelamar_2 from penerimaan_prodi pp, pendaftaran_prodi p
        where p.id_pendaftaran = new.id_pendaftaran and 
        pp.kode_prodi = OLD.kode_prodi and
        pp.nomor_periode = nomor_periode_old and
        pp.tahun_periode = tahun_periode_old;
        jml_pelamar_1 := jml_pelamar_1 + 1;
        jml_pelamar_2 := jml_pelamar_2 - 1;
      END IF; 

    return new;
  end;
$$;


SET search_path = aviationtest, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: airplane; Type: TABLE; Schema: aviationtest; Owner: -
--

CREATE TABLE airplane (
    airplane_id character(5) NOT NULL,
    airplane_type character varying(20)
);


--
-- Name: airplane_type; Type: TABLE; Schema: aviationtest; Owner: -
--

CREATE TABLE airplane_type (
    type_name character varying(20) NOT NULL,
    max_seats smallint NOT NULL,
    company character varying(30) NOT NULL
);


--
-- Name: airport; Type: TABLE; Schema: aviationtest; Owner: -
--

CREATE TABLE airport (
    airport_code airportcode NOT NULL,
    name character varying(40) NOT NULL,
    city character varying(25) NOT NULL,
    state character varying(25) NOT NULL,
    country character varying(25) NOT NULL
);


--
-- Name: fare; Type: TABLE; Schema: aviationtest; Owner: -
--

CREATE TABLE fare (
    flight_num noflight NOT NULL,
    fare_code character(1) NOT NULL,
    amount integer NOT NULL
);


--
-- Name: flight; Type: TABLE; Schema: aviationtest; Owner: -
--

CREATE TABLE flight (
    flight_num noflight NOT NULL,
    airline character varying(25) NOT NULL,
    weekdays character varying(10) NOT NULL,
    dept_airport airportcode NOT NULL,
    sch_dept_time time without time zone NOT NULL,
    arr_airport airportcode NOT NULL,
    sch_arr_time time without time zone NOT NULL
);


--
-- Name: flight_instance; Type: TABLE; Schema: aviationtest; Owner: -
--

CREATE TABLE flight_instance (
    flight_num noflight NOT NULL,
    date date NOT NULL,
    airplane_id character(5),
    num_seats smallint,
    dept_time time without time zone,
    arr_time time without time zone
);


--
-- Name: seat_reservation; Type: TABLE; Schema: aviationtest; Owner: -
--

CREATE TABLE seat_reservation (
    flight_num noflight NOT NULL,
    date date NOT NULL,
    seat_num character(3) NOT NULL,
    fare_code character(1) NOT NULL,
    cus_name character varying(30) NOT NULL,
    cus_phone character(12) NOT NULL
);


SET search_path = latihan_kuis_1, pg_catalog;

--
-- Name: dosen; Type: TABLE; Schema: latihan_kuis_1; Owner: -
--

CREATE TABLE dosen (
    nip character(10) NOT NULL,
    nama character varying(100) NOT NULL,
    ruangan character varying(10) NOT NULL,
    telepon character varying(15),
    email character varying(100) NOT NULL
);


--
-- Name: kelas; Type: TABLE; Schema: latihan_kuis_1; Owner: -
--

CREATE TABLE kelas (
    kode_mk character varying(10) NOT NULL,
    semester character varying(10) NOT NULL,
    tahun character varying(10) NOT NULL,
    nama character(1) NOT NULL,
    nip_dosen character(10) NOT NULL
);


--
-- Name: mahasiswa; Type: TABLE; Schema: latihan_kuis_1; Owner: -
--

CREATE TABLE mahasiswa (
    npm character(10) NOT NULL,
    nama character varying(100) NOT NULL,
    angkatan character(4) NOT NULL,
    fakultas character varying(100) NOT NULL,
    prodi character varying(100) NOT NULL,
    nip_pa character(10) NOT NULL
);


--
-- Name: mata_kuliah; Type: TABLE; Schema: latihan_kuis_1; Owner: -
--

CREATE TABLE mata_kuliah (
    kode_mk character varying(10) NOT NULL,
    nama character varying(100) NOT NULL,
    sks integer NOT NULL,
    prodi character varying(100) NOT NULL
);


--
-- Name: transkrip; Type: TABLE; Schema: latihan_kuis_1; Owner: -
--

CREATE TABLE transkrip (
    kode_mk character varying(10) NOT NULL,
    semester character varying(10) NOT NULL,
    tahun character varying(10) NOT NULL,
    nama character(1) NOT NULL,
    npm character(10) NOT NULL,
    nilai_angka real,
    nilai_huruf character(1)
);


SET search_path = sirenkom, pg_catalog;

--
-- Name: anggota; Type: TABLE; Schema: sirenkom; Owner: -
--

CREATE TABLE anggota (
    no_anggota character(6) NOT NULL,
    nama_lengkap character varying(100) NOT NULL,
    no_identitas character varying(50) NOT NULL,
    jenis_identitas character varying(50) NOT NULL,
    jenis_kelamin character(1),
    ttl date,
    alamat character varying(100) NOT NULL,
    no_telp character varying(15),
    status boolean DEFAULT true
);


--
-- Name: detail_peminjaman; Type: TABLE; Schema: sirenkom; Owner: -
--

CREATE TABLE detail_peminjaman (
    id_peminjaman integer NOT NULL,
    no_komik character(6) NOT NULL,
    no_volume integer NOT NULL,
    tgl_kembali date,
    denda integer DEFAULT 0
);


--
-- Name: komik; Type: TABLE; Schema: sirenkom; Owner: -
--

CREATE TABLE komik (
    no_komik character(6) NOT NULL,
    judul character varying(100) NOT NULL,
    pengarang character varying(100) NOT NULL,
    penerbit character varying(100),
    jumlah_volume integer NOT NULL,
    genre character varying(50),
    harga_sewa integer NOT NULL,
    frekuensi_dipinjam integer DEFAULT 0
);


--
-- Name: peminjaman; Type: TABLE; Schema: sirenkom; Owner: -
--

CREATE TABLE peminjaman (
    id_peminjaman integer NOT NULL,
    no_anggota character(6) NOT NULL,
    id_petugas character(6) NOT NULL,
    total_harga integer NOT NULL,
    tgl_pinjam date NOT NULL
);


--
-- Name: peminjaman_id_peminjaman_seq; Type: SEQUENCE; Schema: sirenkom; Owner: -
--

CREATE SEQUENCE peminjaman_id_peminjaman_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: peminjaman_id_peminjaman_seq; Type: SEQUENCE OWNED BY; Schema: sirenkom; Owner: -
--

ALTER SEQUENCE peminjaman_id_peminjaman_seq OWNED BY peminjaman.id_peminjaman;


--
-- Name: petugas; Type: TABLE; Schema: sirenkom; Owner: -
--

CREATE TABLE petugas (
    id_petugas character(6) NOT NULL,
    nama_lengkap character varying(100) NOT NULL,
    alamat character varying(100) NOT NULL,
    no_telp character varying(15) NOT NULL
);


SET search_path = tk_basdat_a02, pg_catalog;

--
-- Name: akun; Type: TABLE; Schema: tk_basdat_a02; Owner: -
--

CREATE TABLE akun (
    username character varying(50) NOT NULL,
    role boolean NOT NULL,
    password character varying(20) NOT NULL
);


--
-- Name: jadwal_penting; Type: TABLE; Schema: tk_basdat_a02; Owner: -
--

CREATE TABLE jadwal_penting (
    nomor smallint NOT NULL,
    tahun character(4) NOT NULL,
    jenjang character(2) NOT NULL,
    waktu_mulai timestamp without time zone NOT NULL,
    waktu_selesai timestamp without time zone NOT NULL,
    deskripsi character varying(150) NOT NULL
);


--
-- Name: jenjang; Type: TABLE; Schema: tk_basdat_a02; Owner: -
--

CREATE TABLE jenjang (
    nama character(2) NOT NULL
);


--
-- Name: lokasi_jadwal; Type: TABLE; Schema: tk_basdat_a02; Owner: -
--

CREATE TABLE lokasi_jadwal (
    kota character varying(100) NOT NULL,
    tempat character varying(150) NOT NULL,
    nomor_periode smallint NOT NULL,
    tahun_periode character(4) NOT NULL,
    jenjang character(2) NOT NULL,
    waktu_awal timestamp without time zone NOT NULL
);


--
-- Name: lokasi_ujian; Type: TABLE; Schema: tk_basdat_a02; Owner: -
--

CREATE TABLE lokasi_ujian (
    kota character varying(100) NOT NULL,
    tempat character varying(150) NOT NULL
);


--
-- Name: pelamar; Type: TABLE; Schema: tk_basdat_a02; Owner: -
--

CREATE TABLE pelamar (
    username character varying(50) NOT NULL,
    nama_lengkap character varying(100) NOT NULL,
    alamat text NOT NULL,
    jenis_kelamin character(1) NOT NULL,
    tanggal_lahir date NOT NULL,
    no_ktp character(16) NOT NULL,
    email character varying(100) NOT NULL
);


--
-- Name: pembayaran; Type: TABLE; Schema: tk_basdat_a02; Owner: -
--

CREATE TABLE pembayaran (
    id integer NOT NULL,
    waktu_bayar timestamp without time zone NOT NULL,
    jumlah_bayar numeric(10,2) NOT NULL,
    id_pendaftaran integer NOT NULL
);


--
-- Name: pembayaran_id_seq; Type: SEQUENCE; Schema: tk_basdat_a02; Owner: -
--

CREATE SEQUENCE pembayaran_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pembayaran_id_seq; Type: SEQUENCE OWNED BY; Schema: tk_basdat_a02; Owner: -
--

ALTER SEQUENCE pembayaran_id_seq OWNED BY pembayaran.id;


--
-- Name: pendaftaran; Type: TABLE; Schema: tk_basdat_a02; Owner: -
--

CREATE TABLE pendaftaran (
    id integer NOT NULL,
    status_lulus boolean,
    status_verifikasi boolean,
    npm character(10),
    pelamar character varying(50) NOT NULL,
    nomor_periode smallint NOT NULL,
    tahun_periode character(4) NOT NULL
);


--
-- Name: pendaftaran_id_seq; Type: SEQUENCE; Schema: tk_basdat_a02; Owner: -
--

CREATE SEQUENCE pendaftaran_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pendaftaran_id_seq; Type: SEQUENCE OWNED BY; Schema: tk_basdat_a02; Owner: -
--

ALTER SEQUENCE pendaftaran_id_seq OWNED BY pendaftaran.id;


--
-- Name: pendaftaran_prodi; Type: TABLE; Schema: tk_basdat_a02; Owner: -
--

CREATE TABLE pendaftaran_prodi (
    id_pendaftaran integer NOT NULL,
    kode_prodi integer NOT NULL,
    status_lulus boolean
);


--
-- Name: pendaftaran_semas; Type: TABLE; Schema: tk_basdat_a02; Owner: -
--

CREATE TABLE pendaftaran_semas (
    id_pendaftaran integer NOT NULL,
    status_hadir boolean,
    nilai_ujian integer,
    no_kartu_ujian character(10),
    lokasi_kota character varying(100) NOT NULL,
    lokasi_tempat character varying(150) NOT NULL
);


--
-- Name: pendaftaran_semas_pascasarjana; Type: TABLE; Schema: tk_basdat_a02; Owner: -
--

CREATE TABLE pendaftaran_semas_pascasarjana (
    id_pendaftaran integer NOT NULL,
    nilai_tpa integer NOT NULL,
    nilai_toefl integer NOT NULL,
    jenjang_terakhir character(2) NOT NULL,
    asal_univ character varying(100) NOT NULL,
    alamat_univ text NOT NULL,
    prodi_terakhir character varying(100) NOT NULL,
    nilai_ipk numeric(10,2) NOT NULL,
    no_ijazah character varying(50) NOT NULL,
    tgl_lulus date NOT NULL,
    jenjang character(2) NOT NULL,
    nama_rekomender character varying(100),
    prop_penelitian character varying(100)
);


--
-- Name: pendaftaran_semas_sarjana; Type: TABLE; Schema: tk_basdat_a02; Owner: -
--

CREATE TABLE pendaftaran_semas_sarjana (
    id_pendaftaran integer NOT NULL,
    asal_sekolah character varying(100) NOT NULL,
    jenis_sma character varying(50) NOT NULL,
    alamat_sekolah text NOT NULL,
    nisn character varying(10) NOT NULL,
    tgl_lulus date NOT NULL,
    nilai_uan numeric(10,2) NOT NULL
);


--
-- Name: pendaftaran_uui; Type: TABLE; Schema: tk_basdat_a02; Owner: -
--

CREATE TABLE pendaftaran_uui (
    id_pendaftaran integer NOT NULL,
    rapot character varying(100) NOT NULL,
    surat_rekomendasi character varying(100) NOT NULL,
    asal_sekolah character varying(100) NOT NULL,
    jenis_sma character varying(50) NOT NULL,
    alamat_sekolah text NOT NULL,
    nisn character varying(10) NOT NULL,
    tgl_lulus date NOT NULL,
    nilai_uan numeric(10,2) NOT NULL
);


--
-- Name: penerimaan_prodi; Type: TABLE; Schema: tk_basdat_a02; Owner: -
--

CREATE TABLE penerimaan_prodi (
    nomor_periode integer NOT NULL,
    tahun_periode character(4) NOT NULL,
    kode_prodi integer NOT NULL,
    kuota integer NOT NULL,
    jumlah_pelamar integer,
    jumlah_diterima integer
);


--
-- Name: pengawas; Type: TABLE; Schema: tk_basdat_a02; Owner: -
--

CREATE TABLE pengawas (
    nomor_induk character varying(16) NOT NULL,
    nama character varying(100) NOT NULL,
    no_telp text NOT NULL,
    lokasi_kota character varying(100) NOT NULL,
    lokasi_tempat character varying(150) NOT NULL,
    lokasi_id smallint NOT NULL
);


--
-- Name: periode_penerimaan; Type: TABLE; Schema: tk_basdat_a02; Owner: -
--

CREATE TABLE periode_penerimaan (
    nomor smallint NOT NULL,
    tahun character(4) NOT NULL,
    status_aktif boolean
);


--
-- Name: program_studi; Type: TABLE; Schema: tk_basdat_a02; Owner: -
--

CREATE TABLE program_studi (
    kode integer NOT NULL,
    nama character varying(100) NOT NULL,
    jenis_kelas character varying(50) NOT NULL,
    nama_fakultas character varying(50) NOT NULL,
    jenjang character(2) NOT NULL
);


--
-- Name: program_studi_kode_seq; Type: SEQUENCE; Schema: tk_basdat_a02; Owner: -
--

CREATE SEQUENCE program_studi_kode_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: program_studi_kode_seq; Type: SEQUENCE OWNED BY; Schema: tk_basdat_a02; Owner: -
--

ALTER SEQUENCE program_studi_kode_seq OWNED BY program_studi.kode;


--
-- Name: rekomendasi; Type: TABLE; Schema: tk_basdat_a02; Owner: -
--

CREATE TABLE rekomendasi (
    tgl_review date NOT NULL,
    id_pendaftaran integer NOT NULL,
    status boolean NOT NULL,
    nilai integer NOT NULL,
    komentar text NOT NULL
);


--
-- Name: ruang_ujian; Type: TABLE; Schema: tk_basdat_a02; Owner: -
--

CREATE TABLE ruang_ujian (
    kota character varying(100) NOT NULL,
    tempat character varying(150) NOT NULL,
    id smallint NOT NULL
);


SET search_path = sirenkom, pg_catalog;

--
-- Name: peminjaman id_peminjaman; Type: DEFAULT; Schema: sirenkom; Owner: -
--

ALTER TABLE ONLY peminjaman ALTER COLUMN id_peminjaman SET DEFAULT nextval('peminjaman_id_peminjaman_seq'::regclass);


SET search_path = tk_basdat_a02, pg_catalog;

--
-- Name: pembayaran id; Type: DEFAULT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pembayaran ALTER COLUMN id SET DEFAULT nextval('pembayaran_id_seq'::regclass);


--
-- Name: pendaftaran id; Type: DEFAULT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pendaftaran ALTER COLUMN id SET DEFAULT nextval('pendaftaran_id_seq'::regclass);


--
-- Name: program_studi kode; Type: DEFAULT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY program_studi ALTER COLUMN kode SET DEFAULT nextval('program_studi_kode_seq'::regclass);


SET search_path = aviationtest, pg_catalog;

--
-- Data for Name: airplane; Type: TABLE DATA; Schema: aviationtest; Owner: -
--

COPY airplane (airplane_id, airplane_type) FROM stdin;
\.
COPY airplane (airplane_id, airplane_type) FROM '$$PATH$$/2428.dat';

--
-- Data for Name: airplane_type; Type: TABLE DATA; Schema: aviationtest; Owner: -
--

COPY airplane_type (type_name, max_seats, company) FROM stdin;
\.
COPY airplane_type (type_name, max_seats, company) FROM '$$PATH$$/2427.dat';

--
-- Data for Name: airport; Type: TABLE DATA; Schema: aviationtest; Owner: -
--

COPY airport (airport_code, name, city, state, country) FROM stdin;
\.
COPY airport (airport_code, name, city, state, country) FROM '$$PATH$$/2424.dat';

--
-- Data for Name: fare; Type: TABLE DATA; Schema: aviationtest; Owner: -
--

COPY fare (flight_num, fare_code, amount) FROM stdin;
\.
COPY fare (flight_num, fare_code, amount) FROM '$$PATH$$/2426.dat';

--
-- Data for Name: flight; Type: TABLE DATA; Schema: aviationtest; Owner: -
--

COPY flight (flight_num, airline, weekdays, dept_airport, sch_dept_time, arr_airport, sch_arr_time) FROM stdin;
\.
COPY flight (flight_num, airline, weekdays, dept_airport, sch_dept_time, arr_airport, sch_arr_time) FROM '$$PATH$$/2425.dat';

--
-- Data for Name: flight_instance; Type: TABLE DATA; Schema: aviationtest; Owner: -
--

COPY flight_instance (flight_num, date, airplane_id, num_seats, dept_time, arr_time) FROM stdin;
\.
COPY flight_instance (flight_num, date, airplane_id, num_seats, dept_time, arr_time) FROM '$$PATH$$/2429.dat';

--
-- Data for Name: seat_reservation; Type: TABLE DATA; Schema: aviationtest; Owner: -
--

COPY seat_reservation (flight_num, date, seat_num, fare_code, cus_name, cus_phone) FROM stdin;
\.
COPY seat_reservation (flight_num, date, seat_num, fare_code, cus_name, cus_phone) FROM '$$PATH$$/2430.dat';

SET search_path = latihan_kuis_1, pg_catalog;

--
-- Data for Name: dosen; Type: TABLE DATA; Schema: latihan_kuis_1; Owner: -
--

COPY dosen (nip, nama, ruangan, telepon, email) FROM stdin;
\.
COPY dosen (nip, nama, ruangan, telepon, email) FROM '$$PATH$$/2419.dat';

--
-- Data for Name: kelas; Type: TABLE DATA; Schema: latihan_kuis_1; Owner: -
--

COPY kelas (kode_mk, semester, tahun, nama, nip_dosen) FROM stdin;
\.
COPY kelas (kode_mk, semester, tahun, nama, nip_dosen) FROM '$$PATH$$/2422.dat';

--
-- Data for Name: mahasiswa; Type: TABLE DATA; Schema: latihan_kuis_1; Owner: -
--

COPY mahasiswa (npm, nama, angkatan, fakultas, prodi, nip_pa) FROM stdin;
\.
COPY mahasiswa (npm, nama, angkatan, fakultas, prodi, nip_pa) FROM '$$PATH$$/2420.dat';

--
-- Data for Name: mata_kuliah; Type: TABLE DATA; Schema: latihan_kuis_1; Owner: -
--

COPY mata_kuliah (kode_mk, nama, sks, prodi) FROM stdin;
\.
COPY mata_kuliah (kode_mk, nama, sks, prodi) FROM '$$PATH$$/2421.dat';

--
-- Data for Name: transkrip; Type: TABLE DATA; Schema: latihan_kuis_1; Owner: -
--

COPY transkrip (kode_mk, semester, tahun, nama, npm, nilai_angka, nilai_huruf) FROM stdin;
\.
COPY transkrip (kode_mk, semester, tahun, nama, npm, nilai_angka, nilai_huruf) FROM '$$PATH$$/2423.dat';

SET search_path = sirenkom, pg_catalog;

--
-- Data for Name: anggota; Type: TABLE DATA; Schema: sirenkom; Owner: -
--

COPY anggota (no_anggota, nama_lengkap, no_identitas, jenis_identitas, jenis_kelamin, ttl, alamat, no_telp, status) FROM stdin;
\.
COPY anggota (no_anggota, nama_lengkap, no_identitas, jenis_identitas, jenis_kelamin, ttl, alamat, no_telp, status) FROM '$$PATH$$/2432.dat';

--
-- Data for Name: detail_peminjaman; Type: TABLE DATA; Schema: sirenkom; Owner: -
--

COPY detail_peminjaman (id_peminjaman, no_komik, no_volume, tgl_kembali, denda) FROM stdin;
\.
COPY detail_peminjaman (id_peminjaman, no_komik, no_volume, tgl_kembali, denda) FROM '$$PATH$$/2436.dat';

--
-- Data for Name: komik; Type: TABLE DATA; Schema: sirenkom; Owner: -
--

COPY komik (no_komik, judul, pengarang, penerbit, jumlah_volume, genre, harga_sewa, frekuensi_dipinjam) FROM stdin;
\.
COPY komik (no_komik, judul, pengarang, penerbit, jumlah_volume, genre, harga_sewa, frekuensi_dipinjam) FROM '$$PATH$$/2433.dat';

--
-- Data for Name: peminjaman; Type: TABLE DATA; Schema: sirenkom; Owner: -
--

COPY peminjaman (id_peminjaman, no_anggota, id_petugas, total_harga, tgl_pinjam) FROM stdin;
\.
COPY peminjaman (id_peminjaman, no_anggota, id_petugas, total_harga, tgl_pinjam) FROM '$$PATH$$/2435.dat';

--
-- Name: peminjaman_id_peminjaman_seq; Type: SEQUENCE SET; Schema: sirenkom; Owner: -
--

SELECT pg_catalog.setval('peminjaman_id_peminjaman_seq', 1, false);


--
-- Data for Name: petugas; Type: TABLE DATA; Schema: sirenkom; Owner: -
--

COPY petugas (id_petugas, nama_lengkap, alamat, no_telp) FROM stdin;
\.
COPY petugas (id_petugas, nama_lengkap, alamat, no_telp) FROM '$$PATH$$/2431.dat';

SET search_path = tk_basdat_a02, pg_catalog;

--
-- Data for Name: akun; Type: TABLE DATA; Schema: tk_basdat_a02; Owner: -
--

COPY akun (username, role, password) FROM stdin;
\.
COPY akun (username, role, password) FROM '$$PATH$$/2437.dat';

--
-- Data for Name: jadwal_penting; Type: TABLE DATA; Schema: tk_basdat_a02; Owner: -
--

COPY jadwal_penting (nomor, tahun, jenjang, waktu_mulai, waktu_selesai, deskripsi) FROM stdin;
\.
COPY jadwal_penting (nomor, tahun, jenjang, waktu_mulai, waktu_selesai, deskripsi) FROM '$$PATH$$/2443.dat';

--
-- Data for Name: jenjang; Type: TABLE DATA; Schema: tk_basdat_a02; Owner: -
--

COPY jenjang (nama) FROM stdin;
\.
COPY jenjang (nama) FROM '$$PATH$$/2439.dat';

--
-- Data for Name: lokasi_jadwal; Type: TABLE DATA; Schema: tk_basdat_a02; Owner: -
--

COPY lokasi_jadwal (kota, tempat, nomor_periode, tahun_periode, jenjang, waktu_awal) FROM stdin;
\.
COPY lokasi_jadwal (kota, tempat, nomor_periode, tahun_periode, jenjang, waktu_awal) FROM '$$PATH$$/2455.dat';

--
-- Data for Name: lokasi_ujian; Type: TABLE DATA; Schema: tk_basdat_a02; Owner: -
--

COPY lokasi_ujian (kota, tempat) FROM stdin;
\.
COPY lokasi_ujian (kota, tempat) FROM '$$PATH$$/2449.dat';

--
-- Data for Name: pelamar; Type: TABLE DATA; Schema: tk_basdat_a02; Owner: -
--

COPY pelamar (username, nama_lengkap, alamat, jenis_kelamin, tanggal_lahir, no_ktp, email) FROM stdin;
\.
COPY pelamar (username, nama_lengkap, alamat, jenis_kelamin, tanggal_lahir, no_ktp, email) FROM '$$PATH$$/2444.dat';

--
-- Data for Name: pembayaran; Type: TABLE DATA; Schema: tk_basdat_a02; Owner: -
--

COPY pembayaran (id, waktu_bayar, jumlah_bayar, id_pendaftaran) FROM stdin;
\.
COPY pembayaran (id, waktu_bayar, jumlah_bayar, id_pendaftaran) FROM '$$PATH$$/2454.dat';

--
-- Name: pembayaran_id_seq; Type: SEQUENCE SET; Schema: tk_basdat_a02; Owner: -
--

SELECT pg_catalog.setval('pembayaran_id_seq', 1, false);


--
-- Data for Name: pendaftaran; Type: TABLE DATA; Schema: tk_basdat_a02; Owner: -
--

COPY pendaftaran (id, status_lulus, status_verifikasi, npm, pelamar, nomor_periode, tahun_periode) FROM stdin;
\.
COPY pendaftaran (id, status_lulus, status_verifikasi, npm, pelamar, nomor_periode, tahun_periode) FROM '$$PATH$$/2446.dat';

--
-- Name: pendaftaran_id_seq; Type: SEQUENCE SET; Schema: tk_basdat_a02; Owner: -
--

SELECT pg_catalog.setval('pendaftaran_id_seq', 1, false);


--
-- Data for Name: pendaftaran_prodi; Type: TABLE DATA; Schema: tk_basdat_a02; Owner: -
--

COPY pendaftaran_prodi (id_pendaftaran, kode_prodi, status_lulus) FROM stdin;
\.
COPY pendaftaran_prodi (id_pendaftaran, kode_prodi, status_lulus) FROM '$$PATH$$/2458.dat';

--
-- Data for Name: pendaftaran_semas; Type: TABLE DATA; Schema: tk_basdat_a02; Owner: -
--

COPY pendaftaran_semas (id_pendaftaran, status_hadir, nilai_ujian, no_kartu_ujian, lokasi_kota, lokasi_tempat) FROM stdin;
\.
COPY pendaftaran_semas (id_pendaftaran, status_hadir, nilai_ujian, no_kartu_ujian, lokasi_kota, lokasi_tempat) FROM '$$PATH$$/2450.dat';

--
-- Data for Name: pendaftaran_semas_pascasarjana; Type: TABLE DATA; Schema: tk_basdat_a02; Owner: -
--

COPY pendaftaran_semas_pascasarjana (id_pendaftaran, nilai_tpa, nilai_toefl, jenjang_terakhir, asal_univ, alamat_univ, prodi_terakhir, nilai_ipk, no_ijazah, tgl_lulus, jenjang, nama_rekomender, prop_penelitian) FROM stdin;
\.
COPY pendaftaran_semas_pascasarjana (id_pendaftaran, nilai_tpa, nilai_toefl, jenjang_terakhir, asal_univ, alamat_univ, prodi_terakhir, nilai_ipk, no_ijazah, tgl_lulus, jenjang, nama_rekomender, prop_penelitian) FROM '$$PATH$$/2452.dat';

--
-- Data for Name: pendaftaran_semas_sarjana; Type: TABLE DATA; Schema: tk_basdat_a02; Owner: -
--

COPY pendaftaran_semas_sarjana (id_pendaftaran, asal_sekolah, jenis_sma, alamat_sekolah, nisn, tgl_lulus, nilai_uan) FROM stdin;
\.
COPY pendaftaran_semas_sarjana (id_pendaftaran, asal_sekolah, jenis_sma, alamat_sekolah, nisn, tgl_lulus, nilai_uan) FROM '$$PATH$$/2451.dat';

--
-- Data for Name: pendaftaran_uui; Type: TABLE DATA; Schema: tk_basdat_a02; Owner: -
--

COPY pendaftaran_uui (id_pendaftaran, rapot, surat_rekomendasi, asal_sekolah, jenis_sma, alamat_sekolah, nisn, tgl_lulus, nilai_uan) FROM stdin;
\.
COPY pendaftaran_uui (id_pendaftaran, rapot, surat_rekomendasi, asal_sekolah, jenis_sma, alamat_sekolah, nisn, tgl_lulus, nilai_uan) FROM '$$PATH$$/2447.dat';

--
-- Data for Name: penerimaan_prodi; Type: TABLE DATA; Schema: tk_basdat_a02; Owner: -
--

COPY penerimaan_prodi (nomor_periode, tahun_periode, kode_prodi, kuota, jumlah_pelamar, jumlah_diterima) FROM stdin;
\.
COPY penerimaan_prodi (nomor_periode, tahun_periode, kode_prodi, kuota, jumlah_pelamar, jumlah_diterima) FROM '$$PATH$$/2442.dat';

--
-- Data for Name: pengawas; Type: TABLE DATA; Schema: tk_basdat_a02; Owner: -
--

COPY pengawas (nomor_induk, nama, no_telp, lokasi_kota, lokasi_tempat, lokasi_id) FROM stdin;
\.
COPY pengawas (nomor_induk, nama, no_telp, lokasi_kota, lokasi_tempat, lokasi_id) FROM '$$PATH$$/2457.dat';

--
-- Data for Name: periode_penerimaan; Type: TABLE DATA; Schema: tk_basdat_a02; Owner: -
--

COPY periode_penerimaan (nomor, tahun, status_aktif) FROM stdin;
\.
COPY periode_penerimaan (nomor, tahun, status_aktif) FROM '$$PATH$$/2438.dat';

--
-- Data for Name: program_studi; Type: TABLE DATA; Schema: tk_basdat_a02; Owner: -
--

COPY program_studi (kode, nama, jenis_kelas, nama_fakultas, jenjang) FROM stdin;
\.
COPY program_studi (kode, nama, jenis_kelas, nama_fakultas, jenjang) FROM '$$PATH$$/2441.dat';

--
-- Name: program_studi_kode_seq; Type: SEQUENCE SET; Schema: tk_basdat_a02; Owner: -
--

SELECT pg_catalog.setval('program_studi_kode_seq', 1, false);


--
-- Data for Name: rekomendasi; Type: TABLE DATA; Schema: tk_basdat_a02; Owner: -
--

COPY rekomendasi (tgl_review, id_pendaftaran, status, nilai, komentar) FROM stdin;
\.
COPY rekomendasi (tgl_review, id_pendaftaran, status, nilai, komentar) FROM '$$PATH$$/2448.dat';

--
-- Data for Name: ruang_ujian; Type: TABLE DATA; Schema: tk_basdat_a02; Owner: -
--

COPY ruang_ujian (kota, tempat, id) FROM stdin;
\.
COPY ruang_ujian (kota, tempat, id) FROM '$$PATH$$/2456.dat';

SET search_path = aviationtest, pg_catalog;

--
-- Name: airplane airplane_pkey; Type: CONSTRAINT; Schema: aviationtest; Owner: -
--

ALTER TABLE ONLY airplane
    ADD CONSTRAINT airplane_pkey PRIMARY KEY (airplane_id);


--
-- Name: airplane_type airplane_type_pkey; Type: CONSTRAINT; Schema: aviationtest; Owner: -
--

ALTER TABLE ONLY airplane_type
    ADD CONSTRAINT airplane_type_pkey PRIMARY KEY (type_name);


--
-- Name: airport airport_pkey; Type: CONSTRAINT; Schema: aviationtest; Owner: -
--

ALTER TABLE ONLY airport
    ADD CONSTRAINT airport_pkey PRIMARY KEY (airport_code);


--
-- Name: fare fare_pkey; Type: CONSTRAINT; Schema: aviationtest; Owner: -
--

ALTER TABLE ONLY fare
    ADD CONSTRAINT fare_pkey PRIMARY KEY (flight_num, fare_code);


--
-- Name: flight_instance flight_instance_pkey; Type: CONSTRAINT; Schema: aviationtest; Owner: -
--

ALTER TABLE ONLY flight_instance
    ADD CONSTRAINT flight_instance_pkey PRIMARY KEY (flight_num, date);


--
-- Name: flight flight_pkey; Type: CONSTRAINT; Schema: aviationtest; Owner: -
--

ALTER TABLE ONLY flight
    ADD CONSTRAINT flight_pkey PRIMARY KEY (flight_num);


--
-- Name: seat_reservation seat_reservation_pkey; Type: CONSTRAINT; Schema: aviationtest; Owner: -
--

ALTER TABLE ONLY seat_reservation
    ADD CONSTRAINT seat_reservation_pkey PRIMARY KEY (flight_num, date, seat_num, fare_code);


SET search_path = latihan_kuis_1, pg_catalog;

--
-- Name: dosen dosen_pkey; Type: CONSTRAINT; Schema: latihan_kuis_1; Owner: -
--

ALTER TABLE ONLY dosen
    ADD CONSTRAINT dosen_pkey PRIMARY KEY (nip);


--
-- Name: kelas kelas_pkey; Type: CONSTRAINT; Schema: latihan_kuis_1; Owner: -
--

ALTER TABLE ONLY kelas
    ADD CONSTRAINT kelas_pkey PRIMARY KEY (kode_mk, semester, tahun, nama);


--
-- Name: mahasiswa mahasiswa_pkey; Type: CONSTRAINT; Schema: latihan_kuis_1; Owner: -
--

ALTER TABLE ONLY mahasiswa
    ADD CONSTRAINT mahasiswa_pkey PRIMARY KEY (npm);


--
-- Name: mata_kuliah mata_kuliah_pkey; Type: CONSTRAINT; Schema: latihan_kuis_1; Owner: -
--

ALTER TABLE ONLY mata_kuliah
    ADD CONSTRAINT mata_kuliah_pkey PRIMARY KEY (kode_mk);


--
-- Name: transkrip transkrip_pkey; Type: CONSTRAINT; Schema: latihan_kuis_1; Owner: -
--

ALTER TABLE ONLY transkrip
    ADD CONSTRAINT transkrip_pkey PRIMARY KEY (kode_mk, semester, tahun, nama, npm);


SET search_path = sirenkom, pg_catalog;

--
-- Name: anggota anggota_no_identitas_key; Type: CONSTRAINT; Schema: sirenkom; Owner: -
--

ALTER TABLE ONLY anggota
    ADD CONSTRAINT anggota_no_identitas_key UNIQUE (no_identitas);


--
-- Name: anggota anggota_pkey; Type: CONSTRAINT; Schema: sirenkom; Owner: -
--

ALTER TABLE ONLY anggota
    ADD CONSTRAINT anggota_pkey PRIMARY KEY (no_anggota);


--
-- Name: detail_peminjaman detail_peminjaman_pkey; Type: CONSTRAINT; Schema: sirenkom; Owner: -
--

ALTER TABLE ONLY detail_peminjaman
    ADD CONSTRAINT detail_peminjaman_pkey PRIMARY KEY (id_peminjaman, no_komik, no_volume);


--
-- Name: komik komik_pkey; Type: CONSTRAINT; Schema: sirenkom; Owner: -
--

ALTER TABLE ONLY komik
    ADD CONSTRAINT komik_pkey PRIMARY KEY (no_komik);


--
-- Name: peminjaman peminjaman_pkey; Type: CONSTRAINT; Schema: sirenkom; Owner: -
--

ALTER TABLE ONLY peminjaman
    ADD CONSTRAINT peminjaman_pkey PRIMARY KEY (id_peminjaman);


--
-- Name: petugas petugas_pkey; Type: CONSTRAINT; Schema: sirenkom; Owner: -
--

ALTER TABLE ONLY petugas
    ADD CONSTRAINT petugas_pkey PRIMARY KEY (id_petugas);


SET search_path = tk_basdat_a02, pg_catalog;

--
-- Name: akun akun_pkey; Type: CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY akun
    ADD CONSTRAINT akun_pkey PRIMARY KEY (username);


--
-- Name: jadwal_penting jadwal_penting_pkey; Type: CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY jadwal_penting
    ADD CONSTRAINT jadwal_penting_pkey PRIMARY KEY (nomor, tahun, jenjang, waktu_mulai);


--
-- Name: jenjang jenjang_pkey; Type: CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY jenjang
    ADD CONSTRAINT jenjang_pkey PRIMARY KEY (nama);


--
-- Name: lokasi_jadwal lokasi_jadwal_pkey; Type: CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY lokasi_jadwal
    ADD CONSTRAINT lokasi_jadwal_pkey PRIMARY KEY (kota, tempat, nomor_periode, tahun_periode, jenjang, waktu_awal);


--
-- Name: lokasi_ujian lokasi_ujian_pkey; Type: CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY lokasi_ujian
    ADD CONSTRAINT lokasi_ujian_pkey PRIMARY KEY (kota, tempat);


--
-- Name: pelamar pelamar_email_key; Type: CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pelamar
    ADD CONSTRAINT pelamar_email_key UNIQUE (email);


--
-- Name: pelamar pelamar_pkey; Type: CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pelamar
    ADD CONSTRAINT pelamar_pkey PRIMARY KEY (username);


--
-- Name: pembayaran pembayaran_pkey; Type: CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pembayaran
    ADD CONSTRAINT pembayaran_pkey PRIMARY KEY (id);


--
-- Name: pendaftaran pendaftaran_pkey; Type: CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pendaftaran
    ADD CONSTRAINT pendaftaran_pkey PRIMARY KEY (id);


--
-- Name: pendaftaran_prodi pendaftaran_prodi_pkey; Type: CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pendaftaran_prodi
    ADD CONSTRAINT pendaftaran_prodi_pkey PRIMARY KEY (id_pendaftaran, kode_prodi);


--
-- Name: pendaftaran_semas_pascasarjana pendaftaran_semas_pascasarjana_pkey; Type: CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pendaftaran_semas_pascasarjana
    ADD CONSTRAINT pendaftaran_semas_pascasarjana_pkey PRIMARY KEY (id_pendaftaran);


--
-- Name: pendaftaran_semas pendaftaran_semas_pkey; Type: CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pendaftaran_semas
    ADD CONSTRAINT pendaftaran_semas_pkey PRIMARY KEY (id_pendaftaran);


--
-- Name: pendaftaran_semas_sarjana pendaftaran_semas_sarjana_pkey; Type: CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pendaftaran_semas_sarjana
    ADD CONSTRAINT pendaftaran_semas_sarjana_pkey PRIMARY KEY (id_pendaftaran);


--
-- Name: pendaftaran_uui pendaftaran_uui_pkey; Type: CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pendaftaran_uui
    ADD CONSTRAINT pendaftaran_uui_pkey PRIMARY KEY (id_pendaftaran);


--
-- Name: penerimaan_prodi penerimaan_prodi_pkey; Type: CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY penerimaan_prodi
    ADD CONSTRAINT penerimaan_prodi_pkey PRIMARY KEY (nomor_periode, tahun_periode, kode_prodi);


--
-- Name: pengawas pengawas_pkey; Type: CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pengawas
    ADD CONSTRAINT pengawas_pkey PRIMARY KEY (nomor_induk);


--
-- Name: periode_penerimaan periode_penerimaan_pkey; Type: CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY periode_penerimaan
    ADD CONSTRAINT periode_penerimaan_pkey PRIMARY KEY (nomor, tahun);


--
-- Name: program_studi program_studi_pkey; Type: CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY program_studi
    ADD CONSTRAINT program_studi_pkey PRIMARY KEY (kode);


--
-- Name: rekomendasi rekomendasi_pkey; Type: CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY rekomendasi
    ADD CONSTRAINT rekomendasi_pkey PRIMARY KEY (tgl_review, id_pendaftaran);


--
-- Name: ruang_ujian ruang_ujian_pkey; Type: CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY ruang_ujian
    ADD CONSTRAINT ruang_ujian_pkey PRIMARY KEY (kota, tempat, id);


SET search_path = sirenkom, pg_catalog;

--
-- Name: detail_peminjaman frekuensi_dipinjam_trigger; Type: TRIGGER; Schema: sirenkom; Owner: -
--

CREATE TRIGGER frekuensi_dipinjam_trigger AFTER INSERT OR DELETE OR UPDATE ON detail_peminjaman FOR EACH ROW EXECUTE PROCEDURE perbarui_kolom_frekuensi_dipinjam_tabel_komik();


--
-- Name: detail_peminjaman jumlah_peminjaman_trigger; Type: TRIGGER; Schema: sirenkom; Owner: -
--

CREATE TRIGGER jumlah_peminjaman_trigger AFTER INSERT ON detail_peminjaman FOR EACH ROW EXECUTE PROCEDURE jumlah_peminjaman_constraint();


--
-- Name: detail_peminjaman volume_trigger; Type: TRIGGER; Schema: sirenkom; Owner: -
--

CREATE TRIGGER volume_trigger AFTER INSERT ON detail_peminjaman FOR EACH ROW EXECUTE PROCEDURE volume_constraint();


SET search_path = tk_basdat_a02, pg_catalog;

--
-- Name: pendaftaran_prodi trigger_jumlah_diterima; Type: TRIGGER; Schema: tk_basdat_a02; Owner: -
--

CREATE TRIGGER trigger_jumlah_diterima BEFORE UPDATE ON pendaftaran_prodi FOR EACH ROW EXECUTE PROCEDURE update_jumlah_diterima();


--
-- Name: pendaftaran_prodi trigger_jumlah_pelamar; Type: TRIGGER; Schema: tk_basdat_a02; Owner: -
--

CREATE TRIGGER trigger_jumlah_pelamar BEFORE INSERT OR DELETE OR UPDATE ON pendaftaran_prodi FOR EACH ROW EXECUTE PROCEDURE update_jumlah_pelamar();


SET search_path = aviationtest, pg_catalog;

--
-- Name: airplane airplane_airplane_type_fkey; Type: FK CONSTRAINT; Schema: aviationtest; Owner: -
--

ALTER TABLE ONLY airplane
    ADD CONSTRAINT airplane_airplane_type_fkey FOREIGN KEY (airplane_type) REFERENCES airplane_type(type_name) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: fare fare_flight_num_fkey; Type: FK CONSTRAINT; Schema: aviationtest; Owner: -
--

ALTER TABLE ONLY fare
    ADD CONSTRAINT fare_flight_num_fkey FOREIGN KEY (flight_num) REFERENCES flight(flight_num) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: flight flight_arr_airport_fkey; Type: FK CONSTRAINT; Schema: aviationtest; Owner: -
--

ALTER TABLE ONLY flight
    ADD CONSTRAINT flight_arr_airport_fkey FOREIGN KEY (arr_airport) REFERENCES airport(airport_code) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: flight flight_dept_airport_fkey; Type: FK CONSTRAINT; Schema: aviationtest; Owner: -
--

ALTER TABLE ONLY flight
    ADD CONSTRAINT flight_dept_airport_fkey FOREIGN KEY (dept_airport) REFERENCES airport(airport_code) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: flight_instance flight_instance_airplane_id_fkey; Type: FK CONSTRAINT; Schema: aviationtest; Owner: -
--

ALTER TABLE ONLY flight_instance
    ADD CONSTRAINT flight_instance_airplane_id_fkey FOREIGN KEY (airplane_id) REFERENCES airplane(airplane_id) ON DELETE RESTRICT;


--
-- Name: flight_instance flight_instance_flight_num_fkey; Type: FK CONSTRAINT; Schema: aviationtest; Owner: -
--

ALTER TABLE ONLY flight_instance
    ADD CONSTRAINT flight_instance_flight_num_fkey FOREIGN KEY (flight_num) REFERENCES flight(flight_num) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: seat_reservation seat_reservation_flight_num_fkey; Type: FK CONSTRAINT; Schema: aviationtest; Owner: -
--

ALTER TABLE ONLY seat_reservation
    ADD CONSTRAINT seat_reservation_flight_num_fkey FOREIGN KEY (flight_num, date) REFERENCES flight_instance(flight_num, date) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: seat_reservation seat_reservation_flight_num_fkey1; Type: FK CONSTRAINT; Schema: aviationtest; Owner: -
--

ALTER TABLE ONLY seat_reservation
    ADD CONSTRAINT seat_reservation_flight_num_fkey1 FOREIGN KEY (flight_num, fare_code) REFERENCES fare(flight_num, fare_code) ON UPDATE CASCADE ON DELETE RESTRICT;


SET search_path = latihan_kuis_1, pg_catalog;

--
-- Name: kelas kelas_kode_mk_fkey; Type: FK CONSTRAINT; Schema: latihan_kuis_1; Owner: -
--

ALTER TABLE ONLY kelas
    ADD CONSTRAINT kelas_kode_mk_fkey FOREIGN KEY (kode_mk) REFERENCES mata_kuliah(kode_mk);


--
-- Name: kelas kelas_nip_dosen_fkey; Type: FK CONSTRAINT; Schema: latihan_kuis_1; Owner: -
--

ALTER TABLE ONLY kelas
    ADD CONSTRAINT kelas_nip_dosen_fkey FOREIGN KEY (nip_dosen) REFERENCES dosen(nip);


--
-- Name: mahasiswa mahasiswa_nip_pa_fkey; Type: FK CONSTRAINT; Schema: latihan_kuis_1; Owner: -
--

ALTER TABLE ONLY mahasiswa
    ADD CONSTRAINT mahasiswa_nip_pa_fkey FOREIGN KEY (nip_pa) REFERENCES dosen(nip);


--
-- Name: transkrip transkrip_kode_mk_fkey; Type: FK CONSTRAINT; Schema: latihan_kuis_1; Owner: -
--

ALTER TABLE ONLY transkrip
    ADD CONSTRAINT transkrip_kode_mk_fkey FOREIGN KEY (kode_mk) REFERENCES mata_kuliah(kode_mk);


--
-- Name: transkrip transkrip_kode_mk_fkey1; Type: FK CONSTRAINT; Schema: latihan_kuis_1; Owner: -
--

ALTER TABLE ONLY transkrip
    ADD CONSTRAINT transkrip_kode_mk_fkey1 FOREIGN KEY (kode_mk, semester, tahun, nama) REFERENCES kelas(kode_mk, semester, tahun, nama);


--
-- Name: transkrip transkrip_npm_fkey; Type: FK CONSTRAINT; Schema: latihan_kuis_1; Owner: -
--

ALTER TABLE ONLY transkrip
    ADD CONSTRAINT transkrip_npm_fkey FOREIGN KEY (npm) REFERENCES mahasiswa(npm);


SET search_path = sirenkom, pg_catalog;

--
-- Name: detail_peminjaman detail_peminjaman_id_peminjaman_fkey; Type: FK CONSTRAINT; Schema: sirenkom; Owner: -
--

ALTER TABLE ONLY detail_peminjaman
    ADD CONSTRAINT detail_peminjaman_id_peminjaman_fkey FOREIGN KEY (id_peminjaman) REFERENCES peminjaman(id_peminjaman) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: detail_peminjaman detail_peminjaman_no_komik_fkey; Type: FK CONSTRAINT; Schema: sirenkom; Owner: -
--

ALTER TABLE ONLY detail_peminjaman
    ADD CONSTRAINT detail_peminjaman_no_komik_fkey FOREIGN KEY (no_komik) REFERENCES komik(no_komik) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: peminjaman peminjaman_id_petugas_fkey; Type: FK CONSTRAINT; Schema: sirenkom; Owner: -
--

ALTER TABLE ONLY peminjaman
    ADD CONSTRAINT peminjaman_id_petugas_fkey FOREIGN KEY (id_petugas) REFERENCES petugas(id_petugas) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: peminjaman peminjaman_no_anggota_fkey; Type: FK CONSTRAINT; Schema: sirenkom; Owner: -
--

ALTER TABLE ONLY peminjaman
    ADD CONSTRAINT peminjaman_no_anggota_fkey FOREIGN KEY (no_anggota) REFERENCES anggota(no_anggota) ON UPDATE CASCADE ON DELETE CASCADE;


SET search_path = tk_basdat_a02, pg_catalog;

--
-- Name: jadwal_penting jadwal_penting_jenjang_fkey; Type: FK CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY jadwal_penting
    ADD CONSTRAINT jadwal_penting_jenjang_fkey FOREIGN KEY (jenjang) REFERENCES jenjang(nama);


--
-- Name: jadwal_penting jadwal_penting_nomor_fkey; Type: FK CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY jadwal_penting
    ADD CONSTRAINT jadwal_penting_nomor_fkey FOREIGN KEY (nomor, tahun) REFERENCES periode_penerimaan(nomor, tahun);


--
-- Name: lokasi_jadwal lokasi_jadwal_kota_fkey; Type: FK CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY lokasi_jadwal
    ADD CONSTRAINT lokasi_jadwal_kota_fkey FOREIGN KEY (kota, tempat) REFERENCES lokasi_ujian(kota, tempat);


--
-- Name: lokasi_jadwal lokasi_jadwal_nomor_periode_fkey; Type: FK CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY lokasi_jadwal
    ADD CONSTRAINT lokasi_jadwal_nomor_periode_fkey FOREIGN KEY (nomor_periode, tahun_periode, jenjang, waktu_awal) REFERENCES jadwal_penting(nomor, tahun, jenjang, waktu_mulai);


--
-- Name: pelamar pelamar_username_fkey; Type: FK CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pelamar
    ADD CONSTRAINT pelamar_username_fkey FOREIGN KEY (username) REFERENCES akun(username);


--
-- Name: pembayaran pembayaran_id_pendaftaran_fkey; Type: FK CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pembayaran
    ADD CONSTRAINT pembayaran_id_pendaftaran_fkey FOREIGN KEY (id_pendaftaran) REFERENCES pendaftaran_semas(id_pendaftaran);


--
-- Name: pendaftaran pendaftaran_nomor_periode_fkey; Type: FK CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pendaftaran
    ADD CONSTRAINT pendaftaran_nomor_periode_fkey FOREIGN KEY (nomor_periode, tahun_periode) REFERENCES periode_penerimaan(nomor, tahun);


--
-- Name: pendaftaran pendaftaran_pelamar_fkey; Type: FK CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pendaftaran
    ADD CONSTRAINT pendaftaran_pelamar_fkey FOREIGN KEY (pelamar) REFERENCES pelamar(username);


--
-- Name: pendaftaran_prodi pendaftaran_prodi_id_pendaftaran_fkey; Type: FK CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pendaftaran_prodi
    ADD CONSTRAINT pendaftaran_prodi_id_pendaftaran_fkey FOREIGN KEY (id_pendaftaran) REFERENCES pendaftaran(id);


--
-- Name: pendaftaran_prodi pendaftaran_prodi_kode_prodi_fkey; Type: FK CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pendaftaran_prodi
    ADD CONSTRAINT pendaftaran_prodi_kode_prodi_fkey FOREIGN KEY (kode_prodi) REFERENCES program_studi(kode);


--
-- Name: pendaftaran_semas pendaftaran_semas_id_pendaftaran_fkey; Type: FK CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pendaftaran_semas
    ADD CONSTRAINT pendaftaran_semas_id_pendaftaran_fkey FOREIGN KEY (id_pendaftaran) REFERENCES pendaftaran(id);


--
-- Name: pendaftaran_semas pendaftaran_semas_lokasi_kota_fkey; Type: FK CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pendaftaran_semas
    ADD CONSTRAINT pendaftaran_semas_lokasi_kota_fkey FOREIGN KEY (lokasi_kota, lokasi_tempat) REFERENCES lokasi_ujian(kota, tempat);


--
-- Name: pendaftaran_semas_pascasarjana pendaftaran_semas_pascasarjana_id_pendaftaran_fkey; Type: FK CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pendaftaran_semas_pascasarjana
    ADD CONSTRAINT pendaftaran_semas_pascasarjana_id_pendaftaran_fkey FOREIGN KEY (id_pendaftaran) REFERENCES pendaftaran_semas(id_pendaftaran);


--
-- Name: pendaftaran_semas_pascasarjana pendaftaran_semas_pascasarjana_jenjang_fkey; Type: FK CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pendaftaran_semas_pascasarjana
    ADD CONSTRAINT pendaftaran_semas_pascasarjana_jenjang_fkey FOREIGN KEY (jenjang) REFERENCES jenjang(nama);


--
-- Name: pendaftaran_semas_pascasarjana pendaftaran_semas_pascasarjana_jenjang_terakhir_fkey; Type: FK CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pendaftaran_semas_pascasarjana
    ADD CONSTRAINT pendaftaran_semas_pascasarjana_jenjang_terakhir_fkey FOREIGN KEY (jenjang_terakhir) REFERENCES jenjang(nama);


--
-- Name: pendaftaran_semas_sarjana pendaftaran_semas_sarjana_id_pendaftaran_fkey; Type: FK CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pendaftaran_semas_sarjana
    ADD CONSTRAINT pendaftaran_semas_sarjana_id_pendaftaran_fkey FOREIGN KEY (id_pendaftaran) REFERENCES pendaftaran_semas(id_pendaftaran);


--
-- Name: pendaftaran_uui pendaftaran_uui_id_pendaftaran_fkey; Type: FK CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pendaftaran_uui
    ADD CONSTRAINT pendaftaran_uui_id_pendaftaran_fkey FOREIGN KEY (id_pendaftaran) REFERENCES pendaftaran(id);


--
-- Name: penerimaan_prodi penerimaan_prodi_kode_prodi_fkey; Type: FK CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY penerimaan_prodi
    ADD CONSTRAINT penerimaan_prodi_kode_prodi_fkey FOREIGN KEY (kode_prodi) REFERENCES program_studi(kode);


--
-- Name: penerimaan_prodi penerimaan_prodi_nomor_periode_fkey; Type: FK CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY penerimaan_prodi
    ADD CONSTRAINT penerimaan_prodi_nomor_periode_fkey FOREIGN KEY (nomor_periode, tahun_periode) REFERENCES periode_penerimaan(nomor, tahun);


--
-- Name: pengawas pengawas_lokasi_kota_fkey; Type: FK CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY pengawas
    ADD CONSTRAINT pengawas_lokasi_kota_fkey FOREIGN KEY (lokasi_kota, lokasi_tempat, lokasi_id) REFERENCES ruang_ujian(kota, tempat, id);


--
-- Name: program_studi program_studi_jenjang_fkey; Type: FK CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY program_studi
    ADD CONSTRAINT program_studi_jenjang_fkey FOREIGN KEY (jenjang) REFERENCES jenjang(nama);


--
-- Name: rekomendasi rekomendasi_id_pendaftaran_fkey; Type: FK CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY rekomendasi
    ADD CONSTRAINT rekomendasi_id_pendaftaran_fkey FOREIGN KEY (id_pendaftaran) REFERENCES pendaftaran_uui(id_pendaftaran);


--
-- Name: ruang_ujian ruang_ujian_kota_fkey; Type: FK CONSTRAINT; Schema: tk_basdat_a02; Owner: -
--

ALTER TABLE ONLY ruang_ujian
    ADD CONSTRAINT ruang_ujian_kota_fkey FOREIGN KEY (kota, tempat) REFERENCES lokasi_ujian(kota, tempat);


--
-- PostgreSQL database dump complete
--

